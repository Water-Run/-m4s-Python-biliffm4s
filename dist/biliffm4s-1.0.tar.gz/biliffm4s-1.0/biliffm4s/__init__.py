r"""
:author: WaterRun
:date: 2025-02-25
:description: biliffm4s库的初始化
:version: 1.0
"""

from .biliffm4s import convert

__all__ = ["convert"]
__version__ = "1.0"
__author__ = "WaterRun"